// Logger.h
// Copyright 2016 Robin.Rowe@CinePaint.org
// Open source license MIT

#ifdef UNREAL_ENGINE
#include "UnrealLogger.h"
#else
#include "SystemLog.h"
#endif
