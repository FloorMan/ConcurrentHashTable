// endian.h
// Copyright 2016 Robin.Rowe@CinePaint.org
// License open source MIT

#ifndef endian_h
#define endian_h

class endian
{
public:
};

#endif
