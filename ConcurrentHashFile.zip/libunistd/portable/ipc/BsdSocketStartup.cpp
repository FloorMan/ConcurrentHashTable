// portable/BsdSocketStartup.cpp
// Created by Robin Rowe on 2019/5/31
// Copyright (c) 2015 Robin.Rowe@CinePaint.org
// License open source MIT

#ifdef _WIN32

#include "BsdSocketStartup.h"

bool portable::BsdSocketStartup::isSingleton;

#endif
