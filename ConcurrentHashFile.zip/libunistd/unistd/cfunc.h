// cfunc.h
// Copyright 2022 CinePaint MIT Open Source
// 15 July 2022 Robin.Rowe@CinePaint.org

#ifndef cfunc_h
#define cfunc_h

#ifdef __cplusplus
#define CFUNC extern "C"
#else
#define CFUNC extern
#define inline __inline
#endif

#endif