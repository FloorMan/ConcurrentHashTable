# Contributor Merges

## 2023/2/23 from Tim Wojtulewicz

$ git pull
remote: Enumerating objects: 210, done.
remote: Counting objects: 100% (91/91), done.
remote: Compressing objects: 100% (49/49), done.
remote: Total 210 (delta 60), reused 57 (delta 42), pack-reused 119
Receiving objects: 100% (210/210), 43.94 KiB | 1.16 MiB/s, done.
Resolving deltas: 100% (119/119), completed with 3 local objects.
From https://github.com/robinrowe/libunistd
   69e8722..923b956  master     -> origin/master
Updating 69e8722..923b956
Fast-forward
 README.md                 | 106 +++++++++++++++++++++++++++++++++++++++++++---
 unistd/CMakeLists.txt     |  15 ++++++-
 unistd/arpa/nameser.h     |  51 ++++++++++++++++++++++
 unistd/fnmatch.cpp        |  11 +++++
 unistd/fnmatch.h          |  10 +++++
 unistd/fts.c              |  20 +++++++++
 unistd/fts.h              |  26 ++++++++++++
 unistd/mem.h              |  29 +++++++++++++
 unistd/net/ethertypes.h   |  12 ++++++
 unistd/net/if_arp.h       |  23 ++++++++++
 unistd/netdb.c            |  14 ++++++
 unistd/netdb.h            |  14 +++++-
 unistd/netinet/icmp6.h    |  44 +++++++++++++++++++
 unistd/netinet/in_systm.h |   0
 unistd/netinet/ip.h       |  48 ++++++++++++++-------
 unistd/netinet/tcp.h      |  47 ++++++++++++++++++++
 unistd/netinet/udp.h      |  20 +++++++++
 unistd/sys/file.cpp       |  92 ++++++++++++++++++++++++++++++++++++++++
 unistd/sys/file.h         |  17 ++++++++
 unistd/sys/random.cpp     |  29 +++++++++++++
 unistd/sys/random.h       |   8 ++++
 unistd/sys/resource.h     |  96 +++++++++++++++++++++++++++++++++++++----
 unistd/syslog.cpp         |  29 +++++++------
 unistd/syslog.h           |   5 ++-
 24 files changed, 719 insertions(+), 47 deletions(-)
 create mode 100644 unistd/arpa/nameser.h
 create mode 100644 unistd/fnmatch.cpp
 create mode 100644 unistd/fnmatch.h
 create mode 100644 unistd/fts.c
 create mode 100644 unistd/fts.h
 create mode 100644 unistd/mem.h
 create mode 100644 unistd/net/ethertypes.h
 create mode 100644 unistd/net/if_arp.h
 create mode 100644 unistd/netdb.c
 create mode 100644 unistd/netinet/icmp6.h
 create mode 100644 unistd/netinet/in_systm.h
 create mode 100644 unistd/netinet/tcp.h
 create mode 100644 unistd/netinet/udp.h
 create mode 100644 unistd/sys/file.cpp
 create mode 100644 unistd/sys/random.cpp
 create mode 100644 unistd/sys/random.h
