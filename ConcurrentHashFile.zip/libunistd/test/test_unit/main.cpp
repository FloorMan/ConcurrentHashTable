// test/UnitTest/main.cpp: 
// robin.rowe@cinepaint.org 2017/3/31

//#include <gettimeofday.h>
//#include <magic.h>
//#include <sys/sys_types.h>
//#include <uni_signal.h>

#include <arpa/inet.h>
#include <dirent.h>
#include <dlfcn.h>
#include <endian.h>
#include <grp.h>
#include <ifaddrs.h>
#include <libgen.h>
#include <libintl.h>
#include <linux/rtc.h>
#include <mqueue.h>
#include <net/if.h>
#include <net/route.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
#include <poll.h>
#include <pthread.h>
#include <pwd.h>
#include <semaphore.h>
#include <strings.h>
#include <sys/epoll.h>
#include <sys/file.h>
#include <sys/inotify.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/poll.h>
#include <sys/prctl.h>
#include <sys/resource.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/socketvar.h>
#include <sys/statvfs.h>
#include <sys/syscall.h>
#include <sys/time.h>
#include <sys/vfs.h>
#include <sys/wait.h>
#include <termios.h>
#include <unistd.h>


int main()
{	return 0;
}